var tipoUser = "cliente";

function mostrarLogin(tipo) {
  if(tipo) tipoUser = tipo;
  esconderTudo();
  document.getElementById("tela-login").style.display = "block";
  document.getElementById("btn-entrar").onclick = function() {
    if(tipoUser === "tecnico") {
      mostrarTecnico();
    } else {
      mostrarHome();
    }
  };
}

function mostrarRegisto() {
  esconderTudo();
  document.getElementById("tela-registo").style.display = "block";
}

function criarConta() {
  var tipo = document.getElementById("tipo-utilizador").value;
  tipoUser = tipo;
  if(tipo === "tecnico") {
    mostrarTecnico();
  } else {
    mostrarHome();
  }
}

function mostrarHome() {
  esconderTudo();
  document.getElementById("tela-home").style.display = "block";
  mostrarMenu();
}

function mostrarTecnico() {
  esconderTudo();
  document.getElementById("tela-tecnico").style.display = "block";
  mostrarMenu();
}

function mostrarPedido(servico) {
  esconderTudo();
  document.getElementById("tela-pedido").style.display = "block";
  document.getElementById("servico-escolhido").textContent = servico;
  mostrarMenu();
}

function pedidoEnviado() {
  esconderTudo();
  document.getElementById("tela-sucesso").style.display = "block";
  mostrarMenu();
}

function aceitarPedido() {
  esconderTudo();
  document.getElementById("tela-aceite").style.display = "block";
  mostrarMenu();
}

function mostrarPerfilTecnico() {
  esconderTudo();
  document.getElementById("tela-perfil-tecnico").style.display = "block";
  mostrarMenu();
}

function mostrarAvaliacao() {
  esconderTudo();
  document.getElementById("tela-avaliacao").style.display = "block";
  mostrarMenu();
}

function enviarAvaliacao() {
  esconderTudo();
  document.getElementById("tela-avaliacao-enviada").style.display = "block";
  mostrarMenu();
}

function mostrarNotificacoes() {
  esconderTudo();
  document.getElementById("tela-notificacoes").style.display = "block";
  mostrarMenu();
}

function mostrarChat() {
  esconderTudo();
  document.getElementById("tela-chat").style.display = "block";
  mostrarMenu();
}

function mostrarMenu() {
  var menu = document.getElementById("menu-nav");
  menu.style.cssText = "position:fixed; bottom:0; left:0; width:100%; background-color:#002060; display:flex; justify-content:space-around; padding:10px 0; border-top:2px solid #FF6600;";
}

function avaliar(nota) {
  var textos = [
    "",
    "😞 Mau serviço",
    "😐 Razoável",
    "🙂 Bom serviço",
    "😊 Muito bom",
    "🤩 Excelente!"
  ];
  document.getElementById("nota-avaliacao").textContent = textos[nota];
}

function enviarMensagem() {
  var campo = document.getElementById("campo-mensagem");
  var mensagem = campo.value;
  if(mensagem.trim() === "") return;
  var div = document.createElement("div");
  div.className = "mensagem-cliente";
  div.innerHTML = "<p>" + mensagem + "</p>";
  document.getElementById("chat-mensagens").appendChild(div);
  campo.value = "";
}

function esconderTudo() {
  var telas = ["tela-inicio","tela-login","tela-registo","tela-home",
  "tela-pedido","tela-sucesso","tela-tecnico","tela-aceite",
  "tela-perfil-tecnico","tela-avaliacao","tela-avaliacao-enviada",
  "tela-notificacoes","tela-chat","menu-nav"];
  telas.forEach(function(id) {
    document.getElementById(id).style.display = "none";
  });
}